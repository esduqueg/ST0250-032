import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class panelPrincipal
{
    JFrame pane;
    
    public panelPrincipal()
    {
        CrearPanel();
        Titulos();
        BotonHorario();
        BotonNotas();
        BotonMaterias();
        BotonModificarHorario();
        BotonSalir();
    }   
    private void Titulos()
    {
        JLabel titulo=new JLabel();
        titulo.setText("BIENVENIDO A LA APP DE LA U");
        titulo.setBounds(100,10,400,70);
        titulo.setHorizontalAlignment(SwingConstants.CENTER);
        titulo.setForeground(Color.cyan);
        titulo.setFont(new Font("cooper black",0,20));
        pane.add(titulo);
    }
    private void CrearPanel()
    {
        pane=new JFrame();
        pane.getContentPane().setBackground(Color.GRAY);
        pane.getContentPane().setLayout(null);
        pane.setSize(600,450);
        pane.setTitle("PROYECTO ING SOFTWARE");
        pane.setLocationRelativeTo(null);
        pane.setVisible(true);
        
    } 
    private void BotonHorario()
    {
        JButton Mi_Horario=new JButton();
        Mi_Horario.setText("MI HORARIO");
        Mi_Horario.setBounds(50,100,200,50);
        Mi_Horario.setEnabled(true);
        pane.add(Mi_Horario);
        
         ActionListener Horario=new ActionListener(){
            
            @Override
            public void actionPerformed(ActionEvent ae)
            {
               new panelHorario();
               pane.setVisible(false);
            }
        };
        Mi_Horario.addActionListener(Horario);
    }
    private void BotonNotas()
    {
        JButton Ingresar_Notas=new JButton();
        Ingresar_Notas.setText("INGRESAR NOTAS");
        Ingresar_Notas.setBounds(320,100,200,50);
        Ingresar_Notas.setEnabled(true);
        pane.add(Ingresar_Notas);
        
        ActionListener Notas=new ActionListener(){
            
            @Override
            public void actionPerformed(ActionEvent ae)
            {
               new panelNotas();   
               pane.setVisible(false);
            }
        };
        Ingresar_Notas.addActionListener(Notas);
    }
    private void BotonMaterias()
    {
        JButton Registrar_Materias=new JButton();
        Registrar_Materias.setText("REGISTRAR MATERIAS");
        Registrar_Materias.setBounds(320,200,200,50);
        Registrar_Materias.setEnabled(true);
        pane.add(Registrar_Materias);
        
        ActionListener Registrar_materias=new ActionListener(){
            
            @Override
            public void actionPerformed(ActionEvent ae)
            {
               new Registrar_Materias();
               pane.setVisible(false);
            }
        };
        Registrar_Materias.addActionListener(Registrar_materias);
    }
    private void BotonModificarHorario()
    {
        JButton Modificar_Horario=new JButton();
        Modificar_Horario.setText("MODIFICAR HORARIO");
        Modificar_Horario.setBounds(50,200,200,50);
        Modificar_Horario.setEnabled(true);
        pane.add(Modificar_Horario);
    }
    private void BotonSalir()
    {       
       
        JButton Salir=new JButton();
        Salir.setText("SALIR");
        Salir.setBounds(230,300,100,40);
        Salir.setEnabled(true);
        Salir.setBackground(Color.magenta.brighter());
        pane.add(Salir);     
        
        ActionListener salir=new ActionListener(){
            
            @Override
            public void actionPerformed(ActionEvent ae)
            {
                JOptionPane.showMessageDialog(null,"SECCION CERRADA EXITOSAMENTE");
                pane.setVisible(false);  
                System.exit(0);
            }
        };
        Salir.addActionListener(salir);
        
    }
}


