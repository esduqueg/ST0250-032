import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.event.ActionListener;
import Conexion.conexion;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class panelRegistro extends javax.swing.JFrame
{
    JFrame pane;
    JTextField cajaTexto=new JTextField();
    JPasswordField cajaTexto2=new JPasswordField();
    conexion conn;
    
    String usuario;
    String contraseña;
    
    public panelRegistro()
    {
        CrearPanel();
        CajasTexto();
        BotonIngresar();
        Titulos();
    }  
    private void CrearPanel()
    {
        pane=new JFrame();
        pane.getContentPane().setBackground(Color.GRAY);
        pane.getContentPane().setLayout(null);
        pane.setSize(400,500);
        pane.setTitle("PROYECTO ING SOFTWARE");
        pane.setLocationRelativeTo(null);
        pane.setVisible(true);       
        
    }   
    private void BotonIngresar()
    {
        
        JButton Ingresar=new JButton();
        Ingresar.setText("INGRESAR");
        Ingresar.setBounds(150,400,100,35);
        Ingresar.setEnabled(true);
        pane.add(Ingresar);
        
        ActionListener oyente;
        oyente = new ActionListener(){
            
            @Override
            public void actionPerformed(ActionEvent ae)
            {
                TraerDatos();
            }
        };
        Ingresar.addActionListener(oyente);
    }
    private void Titulos()
    {
        JLabel titulo=new JLabel();
        titulo.setText("Realizar Ingreso a la app");
        titulo.setBounds(40,20,300,30);
        titulo.setHorizontalAlignment(SwingConstants.CENTER);
        titulo.setForeground(Color.cyan);
        titulo.setFont(new Font("cooper black",0,20));
        pane.add(titulo);
        
        
        JLabel titulo2=new JLabel();
        titulo2.setText("Usuario:");
        titulo2.setBounds(40,100,100,30);
        titulo2.setHorizontalAlignment(SwingConstants.CENTER);
        titulo2.setForeground(Color.yellow);
        titulo2.setFont(new Font("cooper black",0,18));
        pane.add(titulo2);
        
        JLabel titulo3=new JLabel();
        titulo3.setText("Contraseña:");
        titulo3.setBounds(40,200,150,30);
        titulo3.setHorizontalAlignment(SwingConstants.CENTER);
        titulo3.setForeground(Color.yellow);
        titulo3.setFont(new Font("cooper black",0,18));
        pane.add(titulo3);
        
        
    }   
    private void CajasTexto()
    {
        cajaTexto.setBounds(150,100,150,30);
        cajaTexto.setText("");
        pane.add(cajaTexto);
        
        cajaTexto2.setBounds(200,200,150,30);
        cajaTexto2.setText("");
        pane.add(cajaTexto2);
    }   
    private void TraerDatos()
    {
        Connection cn=null;
        conn=new conexion();
        
        String sq1="SELECT * FROM registro";
        String datos []=new String[2];
        Statement st;
        
        try
        {
         cn=conn.getConection();
         st=cn.createStatement();
         ResultSet rs=st.executeQuery(sq1);
         
         while(rs.next())
         {
             usuario=rs.getString(1);
             contraseña=rs.getString(2);
             Evaluar();
         }
            
        }catch(Exception e)
        {
            System.out.println(e);
        }
    }  
    private void Evaluar()
    {
        String Usuario=cajaTexto.getText();
        String Contraseña=cajaTexto2.getText();
        
   
        try{
             if(usuario.equals(Usuario) && contraseña.equals(Contraseña))
           {
              new panelPrincipal();
              pane.setVisible(false);
           }
        }
        catch(Exception e)
        {
             JOptionPane.showMessageDialog(null,"Contraseña Incorrecta");
        }
      
    }
}


