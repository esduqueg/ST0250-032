
/**
 *
 * @author duque
 */
import Conexion.conexion;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Registrar_Materias {
    JFrame pane;
    conexion conn;
    
    JTextField cajaTexto;
    JTextField cajaTexto2;
    JTextField cajaTexto3;
    
    public Registrar_Materias()
    {
        CrearPanel();
        Botones();
        Titulos();
        CajasTexto();
    }
    
    private void CrearPanel()
    {
        pane=new JFrame();
        pane.getContentPane().setBackground(Color.GRAY);
        pane.getContentPane().setLayout(null);
        pane.setSize(600,400);
        pane.setTitle("PROYECTO ING SOFTWARE");
        pane.setLocationRelativeTo(null);
        pane.setVisible(true);    
    }
    
    private void Botones()
    {        
        JButton salir=new JButton();
        salir.setText("SALIR");
        salir.setBounds(440,320,100,20);
        salir.setEnabled(true);
        pane.add(salir);
        
        JButton Principal=new JButton();
        Principal.setText("VOLVER");
        Principal.setBounds(50,320,100,20);
        Principal.setEnabled(true);
        pane.add(Principal);
        
        JButton Notas=new JButton();
        Notas.setText("AGREGAR MATERIA");
        Notas.setBounds(220,320,160,20);
        Notas.setBackground(Color.cyan);
        Notas.setEnabled(true);
        pane.add(Notas);
        
        ActionListener Salir=new ActionListener(){
            
            @Override
            public void actionPerformed(ActionEvent ae)
            {
               JOptionPane.showMessageDialog(null,"SECCION CERRADA EXITOSAMENTE");
               pane.setVisible(false);
               System.exit(0);
            }
        };
        salir.addActionListener(Salir);
        
        ActionListener volver=new ActionListener(){
            
            @Override
            public void actionPerformed(ActionEvent ae)
            {
              new panelPrincipal();
              pane.setVisible(false);
            }
        };
        Principal.addActionListener(volver);
        
        ActionListener agregar_materia;
        agregar_materia = new ActionListener(){
            
            @Override
            public void actionPerformed(ActionEvent ae)
            {
                String codigo=cajaTexto.getText();
                String nombre=cajaTexto2.getText();
                String creditos=cajaTexto3.getText();
               
                Connection cn=null;
                conn=new conexion();
                
                try {
                    cn=conn.getConection();
                    PreparedStatement en=cn.prepareStatement("INSERT INTO materias(Codigo_Materia,Nombre_Materia,Creditos_Materia,Porcentaje_Evaluado,Nota_Acumulada) VALUES ('"+codigo+"','"+nombre+"','"+creditos+"','0','0')");
                    en.executeUpdate();
                    JOptionPane.showMessageDialog(null,"MATERIA REGISTRADA EXITOSAMENTE");
                    Limpiar_Cajas();
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null,"NO PUDE REGISTRAR");
                }
                
            }
        };
        Notas.addActionListener(agregar_materia);
    }
    
    
     private void Titulos()
    {
        JLabel titulo=new JLabel();
        titulo.setText("REGISTRO DE MATERIAS");
        titulo.setBounds(90,10,400,70);
        titulo.setHorizontalAlignment(SwingConstants.CENTER);
        titulo.setForeground(Color.CYAN);
        titulo.setFont(new Font("cooper black",0,20));
        pane.add(titulo);
        
        JLabel mensaje=new JLabel();
        mensaje.setText("* Ingrese las materias matriculadas para el semestre *");
        mensaje.setBounds(90,50,400,40);
        mensaje.setHorizontalAlignment(SwingConstants.CENTER);
        mensaje.setForeground(Color.BLACK);
        mensaje.setFont(new Font("cooper black",0,10));
        pane.add(mensaje);
        
        
        JLabel codigo_materia=new JLabel();
        codigo_materia.setText("Codigo: ");
        codigo_materia.setBounds(50,80,100,70);
        codigo_materia.setHorizontalAlignment(SwingConstants.CENTER);
        codigo_materia.setForeground(Color.yellow);
        codigo_materia.setFont(new Font("cooper black",0,18));
        pane.add(codigo_materia);
        
        JLabel nombre_materia=new JLabel();
        nombre_materia.setText("Nombre: ");
        nombre_materia.setBounds(50,140,100,70);
        nombre_materia.setHorizontalAlignment(SwingConstants.CENTER);
        nombre_materia.setForeground(Color.yellow);
        nombre_materia.setFont(new Font("cooper black",0,18));
        pane.add(nombre_materia);
        
        JLabel credito_materia=new JLabel();
        credito_materia.setText("# Creditos: ");
        credito_materia.setBounds(50,200,140,70);
        credito_materia.setHorizontalAlignment(SwingConstants.CENTER);
        credito_materia.setForeground(Color.yellow);
        credito_materia.setFont(new Font("cooper black",0,18));
        pane.add(credito_materia);
        
    }
     
     private void CajasTexto()
    {
        cajaTexto=new JTextField();
        cajaTexto.setBounds(190,100,150,30);
        cajaTexto.setText("");
        pane.add(cajaTexto);
        
        cajaTexto2=new JTextField();
        cajaTexto2.setBounds(190,160,150,30);
        cajaTexto2.setText("");
        pane.add(cajaTexto2);
        
        cajaTexto3=new JTextField();
        cajaTexto3.setBounds(190,220,150,30);
        cajaTexto3.setText("");
        pane.add(cajaTexto3);
    }
     
     public void Limpiar_Cajas()
     {
         cajaTexto.setText(null);
         cajaTexto2.setText(null);
         cajaTexto3.setText(null);
         
     }
}
