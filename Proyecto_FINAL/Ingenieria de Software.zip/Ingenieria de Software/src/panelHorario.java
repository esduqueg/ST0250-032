import Conexion.conexion;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.table.DefaultTableModel;
public class panelHorario
{
    JFrame pane;
    conexion conn;
    
    JTable table;
    
    public panelHorario()
    {
        CrearPanel();
        Tabla();
        Botones();
        Titulos();
    }
    
    private void CrearPanel()
    {
        pane=new JFrame();
        pane.getContentPane().setBackground(Color.GRAY);
        pane.getContentPane().setLayout(null);
        pane.setSize(600,400);
        pane.setTitle("PROYECTO ING SOFTWARE");
        pane.setLocationRelativeTo(null);
        pane.setVisible(true);
    }
    
    private void Tabla()
    {
        table=new JTable();
        table.setBounds(40,80,500,200);
        pane.add(table);
        
        
        Connection cn=null;
        conn=new conexion();
        
        String sql="SELECT * FROM horario";
        Statement st;
        DefaultTableModel modelo=new DefaultTableModel();
        
        modelo.addColumn("MATERIA");
        modelo.addColumn("AULA");
        modelo.addColumn("DIA");
        modelo.addColumn("HORA");
        
        table.setModel(modelo);
        String [] datos=new String [4];
       
        try
        {
            cn=conn.getConection();
            st=cn.createStatement();
            ResultSet dt=st.executeQuery(sql);
            
            while(dt.next())
            {
                datos[0]=dt.getString(1);
                datos[1]=dt.getString(2);
                datos[2]=dt.getString(3);
                datos[3]=dt.getString(4);
                modelo.addRow(datos);
                
            }
        }catch(Exception e)
        {
            
        }
        
    }
    
    private void Botones()
    {
        JButton salir=new JButton();
        salir.setText("SALIR");
        salir.setBounds(440,320,100,20);
        salir.setEnabled(true);
        pane.add(salir);
        
        
        JButton Principal=new JButton();
        Principal.setText("VOLVER");
        Principal.setBounds(50,320,100,20);
        Principal.setEnabled(true);
        pane.add(Principal);
        
        JButton Horario=new JButton();
        Horario.setText("INGRESAR  HORARIO");
        Horario.setBounds(200,320,180,20);
        Horario.setBackground(Color.cyan);
        Horario.setEnabled(true);
        pane.add(Horario);
        
        ActionListener Salir=new ActionListener(){
            
            @Override
            public void actionPerformed(ActionEvent ae)
            {
               JOptionPane.showMessageDialog(null,"SECCION CERRADA EXITOSAMENTE");
               pane.setVisible(false);
               System.exit(0);
            }
        };
       
        salir.addActionListener(Salir);
        
         ActionListener Registrar_horario=new ActionListener(){
            
            @Override
            public void actionPerformed(ActionEvent ae)
            {
               new Registrar_Horario();
               pane.setVisible(false);
            }
        };
        Horario.addActionListener(Registrar_horario);
        
        ActionListener volver=new ActionListener(){
            
            @Override
            public void actionPerformed(ActionEvent ae)
            {
              new panelPrincipal();
              pane.setVisible(false);
            }
        };
        Principal.addActionListener(volver);
    }
    
    private void Titulos()
    {
        JLabel titulo=new JLabel();
        titulo.setText("HORARIO DE LA U");
        titulo.setBounds(90,20,400,70);
        titulo.setHorizontalAlignment(SwingConstants.CENTER);
        titulo.setForeground(Color.CYAN);
        titulo.setFont(new Font("cooper black",0,20));
        pane.add(titulo);
    }
  
}

