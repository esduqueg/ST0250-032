

/**
 *
 * @author duque
 */
import Conexion.conexion;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
public class Registrar_Horario {
    
    JFrame pane;
    conexion conn;
    
    JTextField cajaTexto;
    JTextField cajaTexto2;
    JTextField cajaTexto3;
    JTextField cajaTexto4;
    
    public Registrar_Horario()
    {
        CrearPanel();
        Botones();
        Titulos();
        CajasTexto();
        
    }
    
    private void CrearPanel()
    {
        pane=new JFrame();
        pane.getContentPane().setBackground(Color.GRAY);
        pane.getContentPane().setLayout(null);
        pane.setSize(600,400);
        pane.setTitle("PROYECTO ING SOFTWARE");
        pane.setLocationRelativeTo(null);
        pane.setVisible(true);    
    }
    
    private void Titulos()
    {
        JLabel titulo=new JLabel();
        titulo.setText("REGISTRO DE HORARIO");
        titulo.setBounds(90,5,400,70);
        titulo.setHorizontalAlignment(SwingConstants.CENTER);
        titulo.setForeground(Color.CYAN);
        titulo.setFont(new Font("cooper black",0,20));
        pane.add(titulo);        
        
        JLabel codigo_materia=new JLabel();
        codigo_materia.setText("Nombre Materia: ");
        codigo_materia.setBounds(50,50,180,70);
        codigo_materia.setHorizontalAlignment(SwingConstants.CENTER);
        codigo_materia.setForeground(Color.yellow);
        codigo_materia.setFont(new Font("cooper black",0,18));
        pane.add(codigo_materia);
        
        JLabel nombre_materia=new JLabel();
        nombre_materia.setText("Aula: ");
        nombre_materia.setBounds(50,110,180,70);
        nombre_materia.setHorizontalAlignment(SwingConstants.CENTER);
        nombre_materia.setForeground(Color.yellow);
        nombre_materia.setFont(new Font("cooper black",0,18));
        pane.add(nombre_materia);
        
        JLabel dia=new JLabel();
        dia.setText("Dia/s: ");
        dia.setBounds(50,170,140,70);
        dia.setHorizontalAlignment(SwingConstants.CENTER);
        dia.setForeground(Color.yellow);
        dia.setFont(new Font("cooper black",0,18));
        pane.add(dia);
        
        JLabel mensaje=new JLabel();
        mensaje.setText("* Lunes-Miercoles... *");
        mensaje.setBounds(50,220,160,20);
        mensaje.setHorizontalAlignment(SwingConstants.CENTER);
        mensaje.setForeground(Color.BLACK);
        mensaje.setFont(new Font("cooper black",0,10));
        pane.add(mensaje);
        
        JLabel hora=new JLabel();
        hora.setText("Hora: ");
        hora.setBounds(50,230,140,70);
        hora.setHorizontalAlignment(SwingConstants.CENTER);
        hora.setForeground(Color.yellow);
        hora.setFont(new Font("cooper black",0,18));
        pane.add(hora);
        
        JLabel mensaje2=new JLabel();
        mensaje2.setText("* 10:00-12:30 pm/am*");
        mensaje2.setBounds(50,280,160,20);
        mensaje2.setHorizontalAlignment(SwingConstants.CENTER);
        mensaje2.setForeground(Color.BLACK);
        mensaje2.setFont(new Font("cooper black",0,10));
        pane.add(mensaje2);
    }
    
    private void Botones()
    {
        JButton Volver=new JButton();
        Volver.setText("VOLVER");
        Volver.setBounds(50,320,100,20);
        Volver.setEnabled(true);
        pane.add(Volver);
        
         ActionListener volver=new ActionListener(){
            
            @Override
            public void actionPerformed(ActionEvent ae)
            {
              new panelHorario();
              pane.setVisible(false);
            }
        };
        Volver.addActionListener(volver);    
        
        //--------------------------------------------------------------------------------------------------
        
        JButton Agregar=new JButton();
        Agregar.setText("AGREGAR  MATERIA/HORARIO");
        Agregar.setBounds(280,320,220,20);
        Agregar.setBackground(Color.cyan);
        Agregar.setEnabled(true);
        pane.add(Agregar);
        
         ActionListener agregar=new ActionListener(){
            
            @Override
            public void actionPerformed(ActionEvent ae)
            {
                String nombre=cajaTexto.getText();
                String aula=cajaTexto2.getText();
                String dia=cajaTexto3.getText();
                String hora=cajaTexto4.getText();    
                
                Connection cn=null;
                conn=new conexion();
                
                try 
                {
                   cn=conn.getConection();
                   PreparedStatement en=cn.prepareStatement("INSERT INTO horario(Nombre_Materia,Aula_Clase,Dia_Clase,Hora_Clase) VALUES ('"+nombre+"','"+aula+"','"+dia+"','"+hora+"')");
                   en.executeUpdate();
                   JOptionPane.showMessageDialog(null,"HORARIO REGISTRADO EXITOSAMENTE");
                   Limpiar_CajasTexto();
                }catch (Exception e) {
                    JOptionPane.showMessageDialog(null,"NO PUDE REGISTRAR");
                }
            }
        };
        Agregar.addActionListener(agregar); 
        
        
          
    }
    
     private void CajasTexto()
    {
        cajaTexto=new JTextField();
        cajaTexto.setBounds(280,70,150,30);
        cajaTexto.setText("");
        pane.add(cajaTexto);
        
        cajaTexto2=new JTextField();
        cajaTexto2.setBounds(280,130,150,30);
        cajaTexto2.setText("");
        pane.add(cajaTexto2);
        
        cajaTexto3=new JTextField();
        cajaTexto3.setBounds(280,190,150,30);
        cajaTexto3.setText("");
        pane.add(cajaTexto3);
        
        cajaTexto4=new JTextField();
        cajaTexto4.setBounds(280,250,150,30);
        cajaTexto4.setText("");
        pane.add(cajaTexto4);
    }
     
    public void Limpiar_CajasTexto()
     {
         cajaTexto.setText(null);
         cajaTexto2.setText(null);
         cajaTexto3.setText(null);
         cajaTexto4.setText(null);
     }
}
