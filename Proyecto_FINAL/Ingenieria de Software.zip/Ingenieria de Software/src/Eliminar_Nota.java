
/**
 *
 * @author duque
 */

import Conexion.conexion;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Eliminar_Nota {
    
    JFrame pane;
    conexion conn;
    JTextField cajaTexto;
    
    public Eliminar_Nota()

    {
        CrearPanel();
        Botones();
        Titulos();
        CajasTexto();
    }
    
    private void CrearPanel()
    {
        pane=new JFrame();
        pane.getContentPane().setBackground(Color.GRAY);
        pane.getContentPane().setLayout(null);
        pane.setSize(600,400);
        pane.setTitle("PROYECTO ING SOFTWARE");
        pane.setLocationRelativeTo(null);
        pane.setVisible(true);    
    }
    
    private void Botones()
    {        
        JButton eliminar=new JButton();
        eliminar.setText("ELIMINAR");
        eliminar.setBounds(230,220,100,20);
        eliminar.setBackground(Color.cyan);
        eliminar.setEnabled(true);
        pane.add(eliminar);
        
        JButton Principal=new JButton();
        Principal.setText("VOLVER");
        Principal.setBounds(230,300,100,20);
        Principal.setEnabled(true);
        pane.add(Principal);
        
        ActionListener volver=new ActionListener(){
            
            @Override
            public void actionPerformed(ActionEvent ae)
            {
              new panelNotas();
              pane.setVisible(false);
            }
        };
        Principal.addActionListener(volver);
    }
    
    private void Titulos()
    {
        JLabel titulo=new JLabel();
        titulo.setText("ELIMINAR REGISTRO");
        titulo.setBounds(90,5,400,70);
        titulo.setHorizontalAlignment(SwingConstants.CENTER);
        titulo.setForeground(Color.CYAN);
        titulo.setFont(new Font("cooper black",0,20));
        pane.add(titulo);
        
        JLabel mensaje=new JLabel();
        mensaje.setText("* Ingrese el codigo de la materia *");
        mensaje.setBounds(90,100,400,40);
        mensaje.setHorizontalAlignment(SwingConstants.CENTER);
        mensaje.setForeground(Color.BLACK);
        mensaje.setFont(new Font("cooper black",0,15));
        pane.add(mensaje);
        
        JLabel mensaje2=new JLabel();
        mensaje2.setText("* Se eliminará el ultimo registro de nota *");
        mensaje2.setBounds(90,50,400,40);
        mensaje2.setHorizontalAlignment(SwingConstants.CENTER);
        mensaje2.setForeground(Color.BLACK);
        mensaje2.setFont(new Font("cooper black",0,15));
        pane.add(mensaje2);
    }
    
    private void CajasTexto()
    {
        cajaTexto=new JTextField();
        cajaTexto.setBounds(200,150,150,30);
        cajaTexto.setText("");
        pane.add(cajaTexto);
    }
}
