import Conexion.conexion;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class panelNotas
{
    JFrame pane;
    
    JComboBox combo;
   
    JTextField cajaTexto2;
    JTextField cajaTexto3;
    
    conexion conn;
    
    String getporcentaje;
    String getnota;
    
    double Getporcentaje;
    double Getnota;
    
    String codigo;
    String porcentaje;
    String nota;
    
    double Textporcentaje;
    double Textnota;
    
    public panelNotas()
    {
        CrearPanel(); 
        Titulos();
        Botones();
        CajasTexto();
    }
    
    private void CrearPanel()
    {
        pane=new JFrame();
        pane.getContentPane().setBackground(Color.GRAY);
        pane.getContentPane().setLayout(null);
        pane.setSize(600,400);
        pane.setTitle("PROYECTO ING SOFTWARE");
        pane.setLocationRelativeTo(null);
        pane.setVisible(true);
        
    }
    
    private void Botones()
    {        
        JButton salir=new JButton();
        salir.setText("SALIR");
        salir.setBounds(440,320,100,20);
        salir.setEnabled(true);
        pane.add(salir);
        
        
        JButton Principal=new JButton();
        Principal.setText("VOLVER");
        Principal.setBounds(50,320,100,20);
        Principal.setEnabled(true);
        pane.add(Principal);
        
        JButton Notas=new JButton();
        Notas.setText("MIS NOTAS");
        Notas.setBounds(240,320,120,20);
        Notas.setBackground(Color.cyan);
        Notas.setEnabled(true);
        pane.add(Notas);
        
        JButton IngresarNota=new JButton();
        IngresarNota.setText("INGRESAR NOTA");
        IngresarNota.setBounds(420,160,140,20);
        IngresarNota.setBackground(Color.cyan);
        IngresarNota.setEnabled(true);
        pane.add(IngresarNota);
        
        JButton Eliminar_Registro=new JButton();
        Eliminar_Registro.setText("ELIMINAR NOTA");
        Eliminar_Registro.setBounds(420,190,140,20);
        Eliminar_Registro.setBackground(Color.cyan);
        Eliminar_Registro.setEnabled(true);
        pane.add(Eliminar_Registro);
        
        ActionListener Salir=new ActionListener(){
            
            @Override
            public void actionPerformed(ActionEvent ae)
            {
               JOptionPane.showMessageDialog(null,"SECCION CERRADA EXITOSAMENTE");
               pane.setVisible(false);
               System.exit(0);
            }
        };
        salir.addActionListener(Salir);
        
        ActionListener volver=new ActionListener(){
            
            @Override
            public void actionPerformed(ActionEvent ae)
            {
              new panelPrincipal();
              pane.setVisible(false);
            }
        };
        Principal.addActionListener(volver);
        
        ActionListener Eliminar=new ActionListener(){
            
            @Override
            public void actionPerformed(ActionEvent ae)
            {
              new Eliminar_Nota();
              pane.setVisible(false);
            }
        };
        Eliminar_Registro.addActionListener(Eliminar);
        
        ActionListener Ingresar=new ActionListener(){
            
            @Override
            public void actionPerformed(ActionEvent ae)
            {
                
                codigo=combo.getSelectedItem().toString();
                System.out.println(codigo);
                porcentaje=cajaTexto3.getText();
                Textporcentaje=Double.parseDouble(porcentaje);
                nota=cajaTexto2.getText();
                Textnota=Double.parseDouble(nota);
                
                Connection cn=null;
                conn=new conexion();
                
                try
                {
                 cn=conn.getConection();
                 Datos();
                
                 PreparedStatement en=cn.prepareStatement("UPDATE materias SET Porcentaje_Evaluado='"+getporcentaje+"' WHERE Nombre_Materia='"+codigo+"'");
                 en.executeUpdate();
                 PreparedStatement en2=cn.prepareStatement("UPDATE materias SET Nota_Acumulada='"+getnota+"' WHERE Nombre_Materia='"+codigo+"'");
                 en2.executeUpdate();
                 JOptionPane.showMessageDialog(null,"NOTA REGISTRADA EXITOSAMENTE");
                 Limpiar_Cajas();
                 
                }catch(Exception e)
                {
                   JOptionPane.showMessageDialog(null,"NO PUDE REGISTRAR NOTA");
                }
            }
        };
        IngresarNota.addActionListener(Ingresar);
    }
    
    private void Titulos()
    {
        JLabel titulo=new JLabel();
        titulo.setText("NOTAS DE LA U");
        titulo.setBounds(90,20,400,70);
        titulo.setHorizontalAlignment(SwingConstants.CENTER);
        titulo.setForeground(Color.CYAN);
        titulo.setFont(new Font("cooper black",0,20));
        pane.add(titulo);
        
        JLabel materia=new JLabel();
        materia.setText("Materia:");
        materia.setBounds(50,80,150,70);
        materia.setHorizontalAlignment(SwingConstants.CENTER);
        materia.setForeground(Color.yellow);
        materia.setFont(new Font("cooper black",0,18));
        pane.add(materia);
        
        JLabel nota=new JLabel();
        nota.setText("Nota:");
        nota.setBounds(50,140,150,70);
        nota.setHorizontalAlignment(SwingConstants.CENTER);
        nota.setForeground(Color.yellow);
        nota.setFont(new Font("cooper black",0,18));
        pane.add(nota);
        
        JLabel porcentaje=new JLabel();
        porcentaje.setText("Porcentaje:");
        porcentaje.setBounds(50,200,150,70);
        porcentaje.setHorizontalAlignment(SwingConstants.CENTER);
        porcentaje.setForeground(Color.yellow);
        porcentaje.setFont(new Font("cooper black",0,18));
        pane.add(porcentaje);
        

    }
    
    private void CajasTexto()
    {
        combo= new JComboBox();
        combo.setBounds(240,100,150,30);
        combo.addItem("Seleccione Materia");
        pane.add(combo);
        
        Connection cn=null;
        conn=new conexion();
        
        String sql="SELECT * FROM materias";
        Statement st;
        
        try
        {
            cn=conn.getConection();
            st=cn.createStatement();
            ResultSet dt=st.executeQuery(sql);
            
            while(dt.next())
            {
                combo.addItem(dt.getString("Nombre_Materia"));
            }
        }catch(Exception e)
        {
            
        }
        
        cajaTexto2=new JTextField();
        cajaTexto2.setBounds(240,160,150,30);
        cajaTexto2.setText("");
        pane.add(cajaTexto2);
        
        cajaTexto3=new JTextField();
        cajaTexto3.setBounds(240,220,150,30);
        cajaTexto3.setText("");
        pane.add(cajaTexto3);
    }
    
     public void Limpiar_Cajas()
     {        
         cajaTexto2.setText(null);
         cajaTexto3.setText(null);      
     }
     
     public void Datos()
     {
        Connection cn=null;
        conn=new conexion();
        String sq1=("SELECT Porcentaje_Evaluado FROM materias WHERE Nombre_Materia='"+codigo+"'");
        String sql2=("SELECT Nota_Acumulada FROM materias WHERE Nombre_Materia='"+codigo+"'");
        Statement st;
        Statement st2;
        
        try
        {
         cn=conn.getConection();
         st=cn.createStatement();
         st2=cn.createStatement();
         ResultSet rs=st.executeQuery(sq1);
         ResultSet rs2=st2.executeQuery(sql2);
         
         while(rs.next() && rs2.next())
         {
             
             getporcentaje=rs.getString(1);
             Getporcentaje=Double.parseDouble(getporcentaje);
             getnota=rs2.getString(1);
             Getnota=Double.parseDouble(getnota);
   
             Operacion();
         }
            
        }catch(Exception e)
        {
            System.out.println("NO PUDE PASAR DE ACA");
        }
     }
     
     public void Operacion()
     {
         double x=Getporcentaje+Textporcentaje;
         
         getporcentaje=Double.toString(x);
               
         double z=Textporcentaje/100;    
         double c=z*Textnota;
         double y=Getnota+c;
         
         getnota=Double.toString(y);
     }
}
