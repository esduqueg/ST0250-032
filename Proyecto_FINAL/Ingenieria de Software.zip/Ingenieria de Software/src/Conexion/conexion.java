package Conexion;

/**
 *
 * @author duque
 */

import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;

public class conexion {
    
    public static final String URL="jdbc:mysql://localhost:3306/scu";
    public static final String USERNAME="root";
    public static final String PASSWORD="deuNJG66";
    
    Connection con = null;
    
    public void conexion(){
        try{
        con=getConection();
        
       }catch(Exception e){
           JOptionPane.showMessageDialog(null,"No pude conectar");
       }
    
    }
    
    public Connection getConection(){
        Connection con=null; 
        try{
            Class.forName("com.mysql.jdbc.Driver");
            con=DriverManager.getConnection(URL, USERNAME, PASSWORD);
            System.out.println("___Conexion establecida___");
            
        }catch(Exception e)
        {
            System.out.println(e);
        }
        return con;
    }
}
